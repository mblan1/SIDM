// src/picker.ts
var params = new URLSearchParams(location.search);
var videoUrl = params.get("url") ?? "";
var $loading = document.getElementById("loading");
var $error = document.getElementById("error");
var $errorText = document.getElementById("error-text");
var $results = document.getElementById("results");
var $videoList = document.getElementById("video-list");
var $audioList = document.getElementById("audio-list");
var $videoEmpty = document.getElementById("video-empty");
var $audioEmpty = document.getElementById("audio-empty");
var $pageTitle = document.getElementById("page-title");
var $pageUrl = document.getElementById("page-url");
var $retry = document.getElementById("retry");
var $cancel = document.getElementById("cancel");
var $audioFormat = document.getElementById("audio-format");
$pageUrl.textContent = videoUrl;
$cancel.addEventListener("click", () => window.close());
$retry.addEventListener("click", () => probe());
function show(which) {
  $loading.hidden = which !== "loading";
  $error.hidden = which !== "error";
  $results.hidden = which !== "results";
}
function fmtBytes(bytes) {
  if (!bytes || bytes <= 0) return "\u2014";
  const units = ["B", "KiB", "MiB", "GiB", "TiB"];
  let v = bytes, u = 0;
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024;
    u++;
  }
  return `${v.toFixed(1)} ${units[u]}`;
}
function metaLine(f) {
  const parts = [];
  if (f.ext) parts.push(f.ext);
  if (f.vcodec) parts.push(f.vcodec);
  if (f.acodec) parts.push(f.acodec);
  if (f.fps && f.fps > 30) parts.push(`${f.fps}fps`);
  return parts.join(" \xB7 ");
}
function renderRow(f, onPick) {
  const li = document.createElement("li");
  li.className = "format-row";
  const left = document.createElement("div");
  left.className = "format-left";
  const label = document.createElement("div");
  label.className = "format-label";
  label.textContent = f.label;
  const meta = document.createElement("div");
  meta.className = "format-meta";
  meta.textContent = metaLine(f);
  left.append(label, meta);
  const size = document.createElement("div");
  size.className = "format-size";
  size.textContent = fmtBytes(f.fileSize);
  li.append(left, size);
  li.addEventListener("click", () => onPick(f));
  return li;
}
var videoTitle;
function render(resp) {
  videoTitle = resp.title ?? void 0;
  $pageTitle.textContent = resp.title ?? videoUrl;
  $videoList.innerHTML = "";
  $audioList.innerHTML = "";
  const videos = resp.formats.filter((f) => f.kind === "video");
  const audios = resp.formats.filter((f) => f.kind === "audio");
  for (const f of videos) $videoList.appendChild(renderRow(f, pick));
  for (const f of audios) $audioList.appendChild(renderRow(f, pick));
  $videoEmpty.hidden = videos.length > 0;
  $audioEmpty.hidden = audios.length > 0;
  show("results");
}
function pick(f) {
  const audioFormat = f.kind === "audio" && $audioFormat.value ? $audioFormat.value : void 0;
  const outExt = audioFormat ?? f.ext;
  const sizeLabel = f.fileSize ? ` \xB7 ${fmtBytes(f.fileSize)}` : "";
  const prettyLabel = audioFormat ? `${f.label} \u2192 ${audioFormat.toUpperCase()}` : `${f.label} \xB7 ${f.ext.toUpperCase()}${sizeLabel}`;
  const safeTitle = (videoTitle ?? "").replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 120);
  const fileName = safeTitle ? `${safeTitle}.${outExt}` : void 0;
  const request = {
    type: "download",
    url: videoUrl,
    fileName,
    ytDlpFormat: f.formatId,
    ytDlpFormatLabel: prettyLabel,
    ytDlpAudioFormat: audioFormat,
    userAgent: navigator.userAgent,
    referer: videoUrl,
    // ext drives the AddDownloadDialog's filename guess + folder memory.
    mime: void 0,
    // A transcode changes the size, so don't seed a wrong total.
    expectedLength: audioFormat ? void 0 : f.fileSize
  };
  chrome.runtime.sendMessage(
    { type: "sidm:capture-manifest", request },
    (resp) => {
      if (resp?.ok) {
        window.close();
      } else {
        $errorText.textContent = `Couldn't send to SIDM: ${resp?.error ?? "unknown error"}`;
        show("error");
      }
    }
  );
}
function probe() {
  if (!videoUrl) {
    $errorText.textContent = "No URL was passed to the picker.";
    show("error");
    return;
  }
  show("loading");
  chrome.runtime.sendMessage(
    { type: "sidm:list-formats", url: videoUrl },
    (resp) => {
      if (chrome.runtime.lastError) {
        $errorText.textContent = chrome.runtime.lastError.message ?? "Background script unreachable.";
        show("error");
        return;
      }
      if (!resp?.ok) {
        const detail = resp?.detail ? `: ${resp.detail}` : "";
        $errorText.textContent = `${resp?.error ?? "Probe failed"}${detail}`;
        show("error");
        return;
      }
      render(resp.response);
    }
  );
}
probe();
//# sourceMappingURL=picker.js.map
