// src/ipc.ts
var NATIVE_HOST_ID = "com.sidm.host";

// src/sniffer.ts
var STORAGE_KEY = "sidm.sniffed.byTab";
async function readState() {
  const stored = await chrome.storage.session.get(STORAGE_KEY);
  return stored[STORAGE_KEY] ?? {};
}
async function listForTab(tabId) {
  const state = await readState();
  return state[tabId] ?? [];
}

// src/version.ts
function isExtensionOutdated(installed, bundled) {
  if (!installed || !bundled || installed === bundled) return false;
  const splitNums = (v) => v.split(/[^0-9]+/).filter((s) => s.length > 0).map((s) => parseInt(s, 10));
  const a = splitNums(installed);
  const b = splitNums(bundled);
  const len = Math.max(a.length, b.length);
  for (let i = 0; i < len; i++) {
    const x = a[i] ?? 0;
    const y = b[i] ?? 0;
    if (x !== y) return x < y;
  }
  return installed < bundled;
}

// src/popup.ts
var $ = (id) => document.getElementById(id);
var settingsBtn = $("settings-btn");
var recheckBtn = $("recheck-btn");
var statusCard = $("status-card");
var connText = $("conn-text");
var connDetail = $("conn-detail");
var captureToggle = $("capture-toggle");
var toggleHint = $("toggle-hint");
var listSection = $("list-section");
var emptySection = $("empty");
var manifestList = $("manifests");
var versionEl = $("version");
var statusEl = $("status");
var updateBanner = $("update-banner");
var updateText = $("update-text");
var reloadBtn = $("reload-btn");
var EXT_VERSION = chrome.runtime.getManifest().version;
versionEl.textContent = `Extension v${EXT_VERSION}`;
settingsBtn.addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
  window.close();
});
recheckBtn.addEventListener("click", checkConnection);
reloadBtn.addEventListener("click", () => {
  reloadBtn.disabled = true;
  reloadBtn.textContent = "Reloading\u2026";
  chrome.runtime.reload();
});
function maybeOfferUpdate(bundledVersion) {
  if (bundledVersion && isExtensionOutdated(EXT_VERSION, bundledVersion)) {
    updateText.textContent = `Update available: v${bundledVersion}`;
    updateBanner.hidden = false;
  } else {
    updateBanner.hidden = true;
  }
}
function reflectToggle(enabled) {
  captureToggle.checked = enabled;
  toggleHint.textContent = enabled ? "Browser downloads are handed to SIDM." : "Off \u2014 downloads use your browser as normal.";
}
async function loadToggle() {
  const { captureEnabled } = await chrome.storage.local.get({ captureEnabled: true });
  reflectToggle(captureEnabled !== false);
}
captureToggle.addEventListener("change", async () => {
  const enabled = captureToggle.checked;
  await chrome.storage.local.set({ captureEnabled: enabled });
  reflectToggle(enabled);
});
function setConn(state, text, detail = "") {
  statusCard.classList.remove("ok", "bad", "checking");
  statusCard.classList.add(state);
  connText.textContent = text;
  connDetail.textContent = detail;
}
function checkConnection() {
  setConn("checking", "Checking connection\u2026");
  let port;
  try {
    port = chrome.runtime.connectNative(NATIVE_HOST_ID);
  } catch (e) {
    setConn("bad", "SIDM not reachable", String(e));
    return;
  }
  let answered = false;
  const timeout = setTimeout(() => {
    if (answered) return;
    port.disconnect();
    setConn("bad", "SIDM not running", "Start the SIDM desktop app, then re-check.");
  }, 4e3);
  port.onMessage.addListener((msg) => {
    if (msg.type !== "hello-response") return;
    answered = true;
    clearTimeout(timeout);
    const hr = msg;
    const caps = hr.capabilities?.length ? hr.capabilities.join(", ") : "\u2014";
    setConn("ok", `Connected to ${hr.appName}`, `App v${hr.appVersion} \xB7 ${caps}`);
    maybeOfferUpdate(hr.bundledExtensionVersion);
    port.disconnect();
  });
  port.onDisconnect.addListener(() => {
    if (answered) return;
    clearTimeout(timeout);
    const err = chrome.runtime.lastError?.message ?? "unknown";
    setConn("bad", "SIDM not reachable", err);
  });
  port.postMessage({
    type: "hello",
    clientName: "SIDM-Chrome-Extension-Popup",
    clientVersion: EXT_VERSION
  });
}
async function loadManifests() {
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!activeTab?.id) {
    showStreams([], "");
    return;
  }
  const manifests = await listForTab(activeTab.id);
  showStreams(manifests, activeTab.url ?? "");
}
function showStreams(manifests, pageUrl) {
  const hasStreams = manifests.length > 0;
  listSection.hidden = !hasStreams;
  emptySection.hidden = hasStreams;
  if (!hasStreams) return;
  manifestList.innerHTML = "";
  for (const m of manifests) {
    manifestList.appendChild(renderItem(m, pageUrl));
  }
}
function renderItem(manifest, pageUrl) {
  const li = document.createElement("li");
  const badge = document.createElement("span");
  badge.className = `kind-badge kind-${manifest.kind}`;
  badge.textContent = manifest.kind;
  const url = document.createElement("span");
  url.className = "manifest-url";
  url.textContent = manifest.url;
  url.title = manifest.url;
  li.appendChild(badge);
  li.appendChild(url);
  li.addEventListener("click", () => capture(manifest, pageUrl));
  return li;
}
async function capture(manifest, pageUrl) {
  statusEl.textContent = "Sending to SIDM\u2026";
  const referer = manifest.pageUrl || pageUrl;
  let cookies;
  try {
    const all = await chrome.cookies.getAll({ url: manifest.url });
    if (all.length > 0) {
      cookies = {};
      for (const c of all) cookies[c.name] = c.value;
    }
  } catch {
  }
  const request = {
    type: "download",
    url: manifest.url,
    referer: referer || void 0,
    userAgent: navigator.userAgent,
    cookies
  };
  chrome.runtime.sendMessage({ type: "sidm:capture-manifest", request }, (reply) => {
    const err = chrome.runtime.lastError?.message;
    if (err) {
      statusEl.textContent = `Failed: ${err}`;
      return;
    }
    statusEl.textContent = reply?.ok ? "Sent. Check SIDM." : reply?.error ?? "Unknown error";
    if (reply?.ok) setTimeout(() => window.close(), 500);
  });
}
void loadToggle();
checkConnection();
void loadManifests();
//# sourceMappingURL=popup.js.map
