// src/ipc.ts
var NATIVE_HOST_ID = "com.sidm.host";

// src/options.ts
var DEFAULTS = {
  captureEnabled: true,
  minSizeBytes: 0,
  bypassHosts: []
};
var $ = (id) => document.getElementById(id);
var captureCheckbox = $("capture-enabled");
var minSizeInput = $("min-size");
var bypassTextarea = $("bypass-hosts");
var saveBtn = $("save-btn");
var saveFeedback = $("save-feedback");
var recheckBtn = $("recheck-btn");
var statusCard = document.querySelector("section.status-card");
var statusText = $("status-text");
var statusDetail = $("status-detail");
var versionLabel = $("version");
async function load() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  const settings = { ...DEFAULTS, ...stored };
  captureCheckbox.checked = settings.captureEnabled;
  minSizeInput.value = String(settings.minSizeBytes);
  bypassTextarea.value = settings.bypassHosts.join("\n");
  versionLabel.textContent = `Extension v${chrome.runtime.getManifest().version}`;
}
async function save() {
  const settings = {
    captureEnabled: captureCheckbox.checked,
    minSizeBytes: Math.max(0, parseInt(minSizeInput.value, 10) || 0),
    bypassHosts: bypassTextarea.value.split("\n").map((s) => s.trim()).filter((s) => s.length > 0)
  };
  await chrome.storage.local.set(settings);
  flash("Saved.");
}
function flash(text) {
  saveFeedback.textContent = text;
  saveFeedback.classList.remove("fading");
  setTimeout(() => saveFeedback.classList.add("fading"), 1200);
  setTimeout(() => {
    saveFeedback.textContent = "";
  }, 1800);
}
function setStatus(state, text, detail = "") {
  statusCard.classList.remove("ok", "bad");
  if (state === "ok") statusCard.classList.add("ok");
  if (state === "bad") statusCard.classList.add("bad");
  statusText.textContent = text;
  statusDetail.textContent = detail;
}
function checkConnection() {
  setStatus("warn", "Checking\u2026");
  let port;
  try {
    port = chrome.runtime.connectNative(NATIVE_HOST_ID);
  } catch (e) {
    setStatus("bad", "Native host not registered", String(e));
    return;
  }
  let answered = false;
  const timeout = setTimeout(() => {
    if (answered) return;
    port.disconnect();
    setStatus(
      "bad",
      "No response from SIDM",
      "Is SIDM running, and did you run `SIDM.App --register-hosts --extension-id <this extension id>`?"
    );
  }, 4e3);
  port.onMessage.addListener((msg) => {
    if (msg.type === "hello-response") {
      answered = true;
      clearTimeout(timeout);
      const hr = msg;
      setStatus(
        "ok",
        `Connected to ${hr.appName}`,
        `version ${hr.appVersion} \u2014 capabilities: ${hr.capabilities.join(", ")}`
      );
      port.disconnect();
    }
  });
  port.onDisconnect.addListener(() => {
    if (answered) return;
    clearTimeout(timeout);
    const err = chrome.runtime.lastError?.message ?? "unknown";
    setStatus("bad", "Native host failed to launch", err);
  });
  port.postMessage({
    type: "hello",
    clientName: "SIDM-Chrome-Extension-Options",
    clientVersion: chrome.runtime.getManifest().version
  });
}
saveBtn.addEventListener("click", save);
recheckBtn.addEventListener("click", checkConnection);
load().then(checkConnection);
//# sourceMappingURL=options.js.map
