// src/sniffer.ts
var STORAGE_KEY = "sidm.sniffed.byTab";
async function readState() {
  const stored = await chrome.storage.session.get(STORAGE_KEY);
  return stored[STORAGE_KEY] ?? {};
}
async function listForTab(tabId) {
  const state = await readState();
  return state[tabId] ?? [];
}

// src/popup.ts
var $ = (id) => document.getElementById(id);
var emptySection = $("empty");
var listSection = $("list-section");
var manifestList = $("manifests");
var settingsBtn = $("settings-btn");
var statusEl = $("status");
settingsBtn.addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
  window.close();
});
async function load() {
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!activeTab?.id) {
    setEmpty();
    return;
  }
  const manifests = await listForTab(activeTab.id);
  if (manifests.length === 0) {
    setEmpty();
    return;
  }
  listSection.hidden = false;
  emptySection.hidden = true;
  manifestList.innerHTML = "";
  for (const m of manifests) {
    manifestList.appendChild(renderItem(m, activeTab.url ?? ""));
  }
}
function setEmpty() {
  listSection.hidden = true;
  emptySection.hidden = false;
}
function renderItem(manifest, pageUrl) {
  const li = document.createElement("li");
  const badge = document.createElement("span");
  badge.className = `kind-badge kind-${manifest.kind}`;
  badge.textContent = manifest.kind;
  const url = document.createElement("span");
  url.className = "manifest-url";
  url.textContent = manifest.url;
  url.title = manifest.url;
  li.appendChild(badge);
  li.appendChild(url);
  li.addEventListener("click", () => capture(manifest, pageUrl));
  return li;
}
async function capture(manifest, pageUrl) {
  statusEl.textContent = "Sending to SIDM\u2026";
  const referer = manifest.pageUrl || pageUrl;
  let cookies;
  try {
    const all = await chrome.cookies.getAll({ url: manifest.url });
    if (all.length > 0) {
      cookies = {};
      for (const c of all) cookies[c.name] = c.value;
    }
  } catch {
  }
  const request = {
    type: "download",
    url: manifest.url,
    referer: referer || void 0,
    userAgent: navigator.userAgent,
    cookies
  };
  chrome.runtime.sendMessage({ type: "sidm:capture-manifest", request }, (reply) => {
    const err = chrome.runtime.lastError?.message;
    if (err) {
      statusEl.textContent = `Failed: ${err}`;
      return;
    }
    statusEl.textContent = reply?.ok ? "Sent. Check SIDM." : reply?.error ?? "Unknown error";
    if (reply?.ok) setTimeout(() => window.close(), 500);
  });
}
load();
//# sourceMappingURL=popup.js.map
