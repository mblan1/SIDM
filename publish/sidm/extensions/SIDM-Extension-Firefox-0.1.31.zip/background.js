// src/ipc.ts
var NATIVE_HOST_ID = "com.sidm.host";

// src/sniffer.ts
var STORAGE_KEY = "sidm.sniffed.byTab";
var MAX_PER_TAB = 16;
var HLS_CONTENT_TYPES = /* @__PURE__ */ new Set([
  "application/vnd.apple.mpegurl",
  "application/x-mpegurl",
  "audio/mpegurl",
  "vnd.apple.mpegurl"
]);
var DASH_CONTENT_TYPES = /* @__PURE__ */ new Set(["application/dash+xml"]);
function classify(url, contentType) {
  const ct = (contentType ?? "").toLowerCase().split(";")[0].trim();
  if (HLS_CONTENT_TYPES.has(ct)) return "hls";
  if (DASH_CONTENT_TYPES.has(ct)) return "dash";
  try {
    const path = new URL(url).pathname.toLowerCase();
    if (path.endsWith(".m3u8") || path.endsWith(".m3u")) return "hls";
    if (path.endsWith(".mpd")) return "dash";
  } catch {
  }
  return null;
}
async function readState() {
  const stored = await chrome.storage.session.get(STORAGE_KEY);
  return stored[STORAGE_KEY] ?? {};
}
async function writeState(state) {
  await chrome.storage.session.set({ [STORAGE_KEY]: state });
}
async function record(tabId, manifest) {
  const state = await readState();
  const list = state[tabId] ?? [];
  if (list.some((m) => m.url === manifest.url)) return;
  list.unshift(manifest);
  if (list.length > MAX_PER_TAB) list.length = MAX_PER_TAB;
  state[tabId] = list;
  await writeState(state);
  await updateBadge(tabId, list.length);
}
async function clearTab(tabId) {
  const state = await readState();
  if (!(tabId in state)) return;
  delete state[tabId];
  await writeState(state);
  await updateBadge(tabId, 0);
}
async function updateBadge(tabId, count) {
  try {
    await chrome.action.setBadgeBackgroundColor({ tabId, color: "#0078D4" });
    await chrome.action.setBadgeText({ tabId, text: count > 0 ? String(count) : "" });
  } catch {
  }
}
function installSniffer() {
  if (!chrome.webRequest) {
    console.warn("[SIDM] chrome.webRequest unavailable; sniffer disabled");
    return;
  }
  chrome.webRequest.onCompleted.addListener(
    (details) => {
      if (details.tabId < 0) return;
      const contentType = details.responseHeaders?.find((h) => h.name.toLowerCase() === "content-type")?.value;
      const kind = classify(details.url, contentType);
      if (!kind) return;
      const manifest = {
        kind,
        url: details.url,
        pageUrl: details.initiator ?? details.documentUrl ?? "",
        capturedAt: Date.now()
      };
      record(details.tabId, manifest).catch((e) => console.error("[SIDM] sniffer record failed:", e));
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders"]
  );
  chrome.webNavigation?.onBeforeNavigate.addListener((details) => {
    if (details.frameId !== 0) return;
    clearTab(details.tabId).catch((e) => console.error("[SIDM] sniffer clear failed:", e));
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    clearTab(tabId).catch((e) => console.error("[SIDM] sniffer cleanup failed:", e));
  });
}

// src/background.ts
var CLIENT_NAME = "SIDM-Chrome-Extension";
var CLIENT_VERSION = chrome.runtime.getManifest().version;
function isExtensionOutdated(installed, bundled) {
  if (!installed || !bundled || installed === bundled) return false;
  const splitNums = (v) => v.split(/[^0-9]+/).filter((s) => s.length > 0).map((s) => parseInt(s, 10));
  const a = splitNums(installed);
  const b = splitNums(bundled);
  const len = Math.max(a.length, b.length);
  for (let i = 0; i < len; i++) {
    const x = a[i] ?? 0;
    const y = b[i] ?? 0;
    if (x !== y) return x < y;
  }
  return installed < bundled;
}
var DEFAULT_SETTINGS = {
  captureEnabled: true,
  minSizeBytes: 0,
  bypassHosts: []
};
var port = null;
var pendingFormatLookups = /* @__PURE__ */ new Map();
function ensurePort() {
  if (port) return port;
  port = chrome.runtime.connectNative(NATIVE_HOST_ID);
  port.onMessage.addListener((msg) => {
    if (msg.type === "hello-response") {
      console.log("[SIDM] Connected to", msg.appName, msg.appVersion);
      if (msg.bundledExtensionVersion && isExtensionOutdated(CLIENT_VERSION, msg.bundledExtensionVersion)) {
        console.log(
          `[SIDM] Self-reload: installed v${CLIENT_VERSION} < bundled v${msg.bundledExtensionVersion}`
        );
        chrome.runtime.reload();
        return;
      }
    } else if (msg.type === "download-response") {
      handleDownloadAck(msg);
    } else if (msg.type === "list-formats-response") {
      const pending = pendingFormatLookups.get(msg.url);
      if (pending) {
        pendingFormatLookups.delete(msg.url);
        pending.resolve(msg);
      }
    } else if (msg.type === "error") {
      if (pendingFormatLookups.size > 0) {
        for (const [, p] of pendingFormatLookups) p.reject(msg);
        pendingFormatLookups.clear();
      }
      handleHostError(msg);
    }
  });
  port.onDisconnect.addListener(() => {
    const reason = chrome.runtime.lastError?.message ?? "unknown";
    console.warn("[SIDM] Native host disconnected:", reason);
    port = null;
  });
  port.postMessage({
    type: "hello",
    clientName: CLIENT_NAME,
    clientVersion: CLIENT_VERSION
  });
  return port;
}
var cachedSettings = { ...DEFAULT_SETTINGS };
var settingsReady = false;
function refreshSettingsCache() {
  chrome.storage.local.get(DEFAULT_SETTINGS, (stored) => {
    cachedSettings = { ...DEFAULT_SETTINGS, ...stored };
    settingsReady = true;
  });
}
refreshSettingsCache();
chrome.storage.onChanged.addListener((_changes, area) => {
  if (area === "local") refreshSettingsCache();
});
function isBypassed(url, bypassHosts) {
  if (bypassHosts.length === 0) return false;
  try {
    const host = new URL(url).hostname;
    return bypassHosts.some((pattern) => host === pattern || host.endsWith("." + pattern));
  } catch {
    return false;
  }
}
async function collectCookies(url) {
  try {
    const cookies = await chrome.cookies.getAll({ url });
    const map = {};
    for (const c of cookies) map[c.name] = c.value;
    return map;
  } catch (e) {
    console.warn("[SIDM] Failed to read cookies:", e);
    return {};
  }
}
function describe(item) {
  return `${item.filename || "(unnamed)"} (${item.fileSize > 0 ? item.fileSize + " bytes" : "size unknown"})`;
}
function captureDownload(item) {
  if (settingsReady) {
    captureWith(item, cachedSettings);
  } else {
    chrome.storage.local.get(DEFAULT_SETTINGS, (stored) => {
      captureWith(item, { ...DEFAULT_SETTINGS, ...stored });
    });
  }
}
function captureWith(item, settings) {
  if (!settings.captureEnabled) return;
  const url = item.finalUrl || item.url;
  if (!url || !/^https?:/i.test(url)) return;
  if (isBypassed(url, settings.bypassHosts)) {
    console.log("[SIDM] Bypassed by user setting:", url);
    return;
  }
  if (settings.minSizeBytes > 0 && item.fileSize > 0 && item.fileSize < settings.minSizeBytes) {
    return;
  }
  chrome.downloads.cancel(item.id).then(
    () => {
      void chrome.downloads.erase({ id: item.id }).catch(() => void 0);
    },
    (e) => console.warn("[SIDM] Could not cancel browser download:", e)
  );
  void forwardToSidm(item, url);
}
async function forwardToSidm(item, url) {
  const cookies = await collectCookies(url);
  const headers = {};
  if (item.referrer) headers["Referer"] = item.referrer;
  const fileName = item.filename ? item.filename.split(/[\\/]/).pop() ?? void 0 : void 0;
  const request = {
    type: "download",
    url,
    fileName,
    headers: Object.keys(headers).length > 0 ? headers : void 0,
    cookies: Object.keys(cookies).length > 0 ? cookies : void 0,
    referer: item.referrer || void 0,
    userAgent: navigator.userAgent,
    expectedLength: item.fileSize > 0 ? item.fileSize : void 0,
    mime: item.mime || void 0
  };
  try {
    ensurePort().postMessage(request);
    console.log("[SIDM] Forwarded:", describe(item));
  } catch (e) {
    notifyError("Could not reach SIDM", String(e));
  }
}
function handleDownloadAck(msg) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "data:image/svg+xml;base64," + btoa(MINIMAL_ICON_SVG),
    title: "SIDM",
    message: `Queued (id ${msg.downloadId}). ${msg.status}`
  });
}
function handleHostError(msg) {
  notifyError(msg.reason, msg.detail ?? "");
}
function notifyError(title, body) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "data:image/svg+xml;base64," + btoa(MINIMAL_ICON_SVG),
    title: `SIDM: ${title}`,
    message: body || " "
  });
}
var MINIMAL_ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48"><rect width="48" height="48" rx="8" fill="#0078D4"/><path d="M24 12 L24 30 M16 24 L24 32 L32 24 M14 36 L34 36" stroke="white" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
function openPickerWindow(url) {
  const target = chrome.runtime.getURL("picker.html") + "?url=" + encodeURIComponent(url);
  return chrome.windows.create({ url: target, type: "popup", width: 480, height: 600 });
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(DEFAULT_SETTINGS, (existing) => {
    chrome.storage.local.set({ ...DEFAULT_SETTINGS, ...existing });
  });
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "sidm-download-link",
      title: "Download with SIDM",
      contexts: ["link", "video", "audio"]
    });
    chrome.contextMenus.create({
      id: "sidm-pick-format",
      title: "Download video / audio with SIDM\u2026",
      contexts: ["page", "video", "audio", "frame", "selection", "link"]
    });
  });
});
chrome.downloads.onCreated.addListener((item) => {
  captureDownload(item);
});
chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId === "sidm-pick-format") {
    const src = info.srcUrl;
    const usableSrc = src && /^https?:/i.test(src) ? src : void 0;
    const url2 = usableSrc ?? info.linkUrl ?? info.frameUrl ?? info.pageUrl;
    if (!url2 || !/^https?:/i.test(url2)) {
      notifyError("Nothing to download here", "Open the page with the video, then try again.");
      return;
    }
    try {
      await openPickerWindow(url2);
    } catch (e) {
      notifyError("Could not open the format picker", String(e));
    }
    return;
  }
  if (info.menuItemId !== "sidm-download-link") return;
  const url = info.linkUrl || info.srcUrl;
  if (!url) return;
  const cookies = await collectCookies(url);
  const headers = {};
  if (info.pageUrl) headers["Referer"] = info.pageUrl;
  const request = {
    type: "download",
    url,
    headers: Object.keys(headers).length > 0 ? headers : void 0,
    cookies: Object.keys(cookies).length > 0 ? cookies : void 0,
    referer: info.pageUrl,
    userAgent: navigator.userAgent
  };
  try {
    ensurePort().postMessage(request);
  } catch (e) {
    notifyError("Could not reach SIDM", String(e));
  }
});
installSniffer();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "sidm:capture-manifest") {
    const request = message.request;
    try {
      ensurePort().postMessage(request);
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
    return true;
  }
  if (message?.type === "sidm:open-picker") {
    const url = String(message.url ?? "");
    if (!url) {
      sendResponse({ ok: false, error: "no url" });
      return true;
    }
    openPickerWindow(url).then(
      () => sendResponse({ ok: true }),
      (e) => sendResponse({ ok: false, error: String(e) })
    );
    return true;
  }
  if (message?.type === "sidm:list-formats") {
    const url = String(message.url ?? "");
    if (!url) {
      sendResponse({ ok: false, error: "no url" });
      return true;
    }
    if (pendingFormatLookups.has(url)) {
      sendResponse({ ok: false, error: "A probe for this URL is already in flight." });
      return true;
    }
    new Promise((resolve, reject) => {
      pendingFormatLookups.set(url, { resolve, reject });
      try {
        ensurePort().postMessage({ type: "list-formats", url });
      } catch (e) {
        pendingFormatLookups.delete(url);
        reject({ type: "error", reason: "NoNativeHost", detail: String(e) });
      }
    }).then(
      (resp) => sendResponse({ ok: true, response: resp }),
      (err) => sendResponse({ ok: false, error: err.reason ?? "failed", detail: err.detail })
    );
    return true;
  }
  return false;
});
//# sourceMappingURL=background.js.map
