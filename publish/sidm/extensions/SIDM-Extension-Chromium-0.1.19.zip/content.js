// src/content.ts
var BUTTON_ID = "sidm-overlay-download";
var LOG = (...args) => console.log("[SIDM]", ...args);
LOG("content script loaded for", location.hostname);
var PLACEMENTS = {
  "youtube.com": [
    // YouTube's right-side player controls: settings gear, subtitles,
    // theater mode, fullscreen. We slot in before the gear so SIDM
    // sits as the LEFT-most icon in that cluster.
    { container: ".ytp-right-controls", anchor: ".ytp-settings-button", inPlayer: true },
    // Last-ditch fallback inside the player area.
    { container: "#movie_player", inPlayer: true }
  ],
  "youtu.be": [
    { container: ".ytp-right-controls", anchor: ".ytp-settings-button", inPlayer: true },
    { container: "#movie_player", inPlayer: true }
  ],
  "vimeo.com": [
    { container: ".player .vp-controls", inPlayer: true }
  ]
  // Twitch / TikTok / Dailymotion / Facebook / Instagram all vary too
  // much site-to-site for a hand-tuned selector; the floating-overlay
  // fallback covers them.
};
function makePlayerChromeButton() {
  const btn = document.createElement("button");
  btn.id = BUTTON_ID;
  btn.type = "button";
  btn.className = "sidm-ytp-button";
  btn.title = "Download this video with SIDM";
  btn.setAttribute("aria-label", "Download with SIDM");
  btn.innerHTML = `
        <svg viewBox="0 0 36 36" aria-hidden="true"
             style="display:block !important; width:24px !important; height:24px !important; flex-shrink:0;">
            <path d="M 18 9 L 18 22 M 12 17 L 18 23 L 24 17 M 11 27 L 25 27"
                  stroke="white" stroke-width="2.4" fill="none"
                  stroke-linecap="round" stroke-linejoin="round" />
        </svg>`;
  btn.style.cssText = `
        width: 38px !important;
        height: 36px !important;
        padding: 0 !important;
        margin: 0 !important;
        border: 0 !important;
        background: transparent !important;
        vertical-align: top !important;
        cursor: pointer !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        opacity: 0.92;
    `;
  btn.addEventListener("mouseenter", () => btn.style.setProperty("opacity", "1", "important"));
  btn.addEventListener("mouseleave", () => btn.style.setProperty("opacity", "0.92", "important"));
  btn.addEventListener("click", onClick);
  return btn;
}
function makePillButton() {
  const btn = document.createElement("button");
  btn.id = BUTTON_ID;
  btn.type = "button";
  btn.title = "Download this video with SIDM";
  btn.setAttribute("aria-label", "Download with SIDM");
  btn.innerHTML = '<span class="sidm-dl-icon">\u2B07</span><span class="sidm-dl-label">SIDM</span>';
  Object.assign(btn.style, {
    display: "inline-flex",
    alignItems: "center",
    gap: "6px",
    padding: "6px 12px",
    marginRight: "8px",
    background: "#0067C0",
    color: "white",
    border: "none",
    borderRadius: "18px",
    font: "500 13px system-ui, sans-serif",
    cursor: "pointer",
    zIndex: "9999"
  });
  btn.addEventListener("click", onClick);
  return btn;
}
function makeFloatingButton() {
  const btn = makePillButton();
  Object.assign(btn.style, {
    position: "fixed",
    top: "16px",
    right: "16px",
    zIndex: "2147483647",
    boxShadow: "0 4px 12px rgba(0,0,0,0.4)"
  });
  return btn;
}
function onClick(e) {
  e.preventDefault();
  e.stopPropagation();
  LOG("button clicked \u2192 asking background to open picker for", location.href);
  chrome.runtime.sendMessage(
    { type: "sidm:open-picker", url: location.href },
    (resp) => {
      if (chrome.runtime.lastError) {
        console.warn("[SIDM] sendMessage failed:", chrome.runtime.lastError.message);
      } else {
        LOG("background ack:", resp);
      }
    }
  );
}
function hostKey() {
  const host = location.hostname.toLowerCase();
  for (const key of Object.keys(PLACEMENTS)) {
    if (host === key || host.endsWith("." + key)) return key;
  }
  return null;
}
function tryPlace() {
  if (document.getElementById(BUTTON_ID)) return true;
  const key = hostKey();
  const rules = key ? PLACEMENTS[key] : [];
  for (const rule of rules) {
    try {
      const container = document.querySelector(rule.container);
      if (!container) continue;
      const btn = rule.inPlayer ? makePlayerChromeButton() : makePillButton();
      if (rule.anchor) {
        const anchor = container.querySelector(rule.anchor);
        if (anchor && anchor.parentNode) {
          anchor.parentNode.insertBefore(btn, anchor);
          LOG("injected before", rule.anchor, "inside", rule.container);
          return true;
        }
      }
      container.prepend(btn);
      LOG("injected into", rule.container, "(prepended)");
      return true;
    } catch (err) {
      console.warn("[SIDM] placement rule failed:", rule, err);
    }
  }
  if (document.querySelector("video")) {
    try {
      document.body.appendChild(makeFloatingButton());
      LOG("injected floating fallback (no host placement matched)");
      return true;
    } catch (err) {
      console.warn("[SIDM] floating fallback failed:", err);
    }
  }
  return false;
}
var lastUrl = location.href;
var attempts = 0;
var MAX_ATTEMPTS = 30;
function tick() {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    attempts = 0;
    const existing = document.getElementById(BUTTON_ID);
    if (existing) {
      LOG("URL changed, removing stale button to re-inject at new player");
      existing.remove();
    }
  }
  if (tryPlace()) return;
  attempts++;
  if (attempts >= MAX_ATTEMPTS) {
    LOG(`gave up after ${MAX_ATTEMPTS} attempts; no matching DOM for ${location.hostname}`);
    return;
  }
  setTimeout(tick, 1e3);
}
tick();
requestAnimationFrame(() => {
  if (!document.getElementById(BUTTON_ID)) tick();
});
var origPush = history.pushState;
history.pushState = function(...args) {
  const r = origPush.apply(this, args);
  setTimeout(tick, 200);
  return r;
};
window.addEventListener("popstate", () => setTimeout(tick, 200));
//# sourceMappingURL=content.js.map
